#if UNITY_2021_1_OR_NEWER
using UnityEngine;
using UnityEditor;
using UnityEditor.Overlays;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    [Overlay(typeof(SceneView), "UMX Settings", true)]
    [Icon("Packages/com.tripolygon.umodeler-x/Editor/Resources/Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar/UMXSettings.png")]
    public class UMXSettingsToolbar : ToolbarOverlay
    {
        public UMXSettingsToolbar() : base("SceneView/UMX Display Settings")
        {
            
        }
    }
}
#endif
