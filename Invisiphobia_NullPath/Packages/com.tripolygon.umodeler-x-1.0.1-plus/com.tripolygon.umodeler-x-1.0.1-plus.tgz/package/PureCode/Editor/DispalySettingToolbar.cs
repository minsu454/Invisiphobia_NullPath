#if UNITY_2021_1_OR_NEWER
using UnityEditor.Toolbars;
using UnityEngine;
using UnityEngine.UIElements;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    [EditorToolbarElement("SceneView/UMX Display Settings")]
    public class DisplaySettingsToolbar : EditorToolbarButton
    {
        public DisplaySettingsToolbar()
        {
            var displayIconSource = UnityEditor.EditorGUIUtility.isProSkin ?
                "Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar/d_UMXDisplaySettings@2x" :
                "Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar/UMXDisplaySettings@2x";
            var dropdownIconSource = UnityEditor.EditorGUIUtility.isProSkin ?
                "Tripolygon/UModelerX/Common/d_IconDropdown@2x" :
                "Tripolygon/UModelerX/Common/IconDropdown@2x";
            var displayIconImage = Resources.Load<Texture2D>(displayIconSource);
            var dropownIconImage = Resources.Load<Texture2D>(dropdownIconSource);

            var displaySettingsIcon = new Image() { tooltip = "UMX Display Settings" };
            displaySettingsIcon.style.backgroundImage = new StyleBackground(displayIconImage);
            displaySettingsIcon.style.backgroundColor = new StyleColor(new Color(0, 0, 0, 0));
            displaySettingsIcon.style.height = 16;
            displaySettingsIcon.style.width = 16;
            displaySettingsIcon.style.marginLeft = 2;
            displaySettingsIcon.style.marginTop = 2;
            displaySettingsIcon.style.marginRight = 2;
            Add(displaySettingsIcon);

            var dropdownIcon = new Image() { tooltip = "UMX Display Settings" };
            dropdownIcon.style.backgroundImage = new StyleBackground(dropownIconImage);
            dropdownIcon.style.backgroundColor = new StyleColor(new Color(0, 0, 0, 0));
            dropdownIcon.style.width = 14;
            dropdownIcon.style.height = 14;
            dropdownIcon.style.marginTop = 3;
            Add(dropdownIcon);

            tooltip = "";
            clicked += ShowDropdown;
        }

        private void ShowDropdown()
        {
            DisplaySettingsPopup.ShowPopup(this);
        }
    }
}
#elif UNITY_2020_1_OR_NEWER
using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using System.Reflection;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    public static class ToolbarCallback
    {
        static Type toolbarType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.Toolbar");
        static Type guiViewType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.GUIView");
        static Type IWindowBackendType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.IWindowBackend");
        static PropertyInfo windowBackendPropertyInfo = guiViewType.GetProperty("windowBackend", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        static PropertyInfo visualTreePropertyInfo = IWindowBackendType.GetProperty("visualTree", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        static FieldInfo OnGUIHandlerField = typeof(IMGUIContainer).GetField("m_OnGUIHandler", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

        static ScriptableObject m_currentToolbar;

        public static Action handler;

        static ToolbarCallback()
        {
            EditorApplication.update -= OnUpdate;
            EditorApplication.update += OnUpdate;
        }

        static void OnUpdate()
        {
            if (m_currentToolbar == null)
            {
                var toolbars = Resources.FindObjectsOfTypeAll(toolbarType);
                m_currentToolbar = toolbars.Length > 0 ? (ScriptableObject)toolbars[0] : null;

                if (m_currentToolbar != null)
                {
                    var windowBackend = windowBackendPropertyInfo.GetValue(m_currentToolbar);
                    var visualTree = (VisualElement)visualTreePropertyInfo.GetValue(windowBackend, null);
                    var container = (IMGUIContainer)visualTree[0];
                    var handler = (Action)OnGUIHandlerField.GetValue(container);
                    handler -= OnGUI;
                    handler += OnGUI;
                    OnGUIHandlerField.SetValue(container, handler);
                }
            }
        }

        static void OnGUI()
        {
            if (handler != null)
            {
                handler();
            }
        }
    }

    [InitializeOnLoad]
    public static class DisplaySettingsToolbar
    {
        private static Texture2D UMXDisplayImage;
        private static Texture2D dropDownImage;

        private static Vector2 UMXDisplaySize = new Vector2(16, 16);
        private static Vector2 dropDownSize = new Vector2(12, 12);

        static DisplaySettingsToolbar()
        {
            ToolbarCallback.handler -= OnGUI;
            ToolbarCallback.handler += OnGUI;
        }

        public static void OnGUI()
        {
            if (UMXDisplayImage == null)
            {
                string UMXImageSource = EditorGUIUtility.isProSkin == true ? "d_UMXDisplaySettings@2x" : "UMXDisplaySettings@2x";
                UMXDisplayImage = Resources.Load<Texture2D>($"Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar/{UMXImageSource}");
            }
            if (dropDownImage == null)
            {
                string dropDownImageSource = EditorGUIUtility.isProSkin == true ? "d_IconDropdown@2x" : "IconDropdown@2x";
                dropDownImage = Resources.Load<Texture2D>($"Tripolygon/UModelerX/Common/{dropDownImageSource}");
            }

            float screenWidth = EditorGUIUtility.currentViewWidth;
            Rect leftRect = new Rect(425, 4, screenWidth, Screen.height);
            leftRect.xMax = (screenWidth - 140) / 2;
            GUIStyle style = ToolbarStyle.buttonStyle;

            // PlayButton과 겹치기 방지
            if (leftRect.xMin + style.fixedWidth <= leftRect.xMax)
            {
                if (GUI.Button(new Rect(leftRect.position, new Vector2(style.fixedWidth, style.fixedHeight)), "", style))
                {
                    UnityEditor.PopupWindow.Show(new Rect(leftRect.position + new Vector2(0, style.fixedHeight), Vector2.zero), new DisplaySettingsPopup());
                }
                GUI.DrawTexture(new Rect(leftRect.position + new Vector2(7, 3), UMXDisplaySize), UMXDisplayImage);
                GUI.DrawTexture(new Rect(leftRect.position + new Vector2(26, 5), dropDownSize), dropDownImage);
            }
        }

#region UMXSettingsToolbarStyle
        static class ToolbarStyle
        {
            public static GUIStyle buttonStyle;

            static ToolbarStyle()
            {
                Type editorGUILayoutType = typeof(EditorGUILayout);

                Type stylesType = editorGUILayoutType.GetNestedType("Styles", BindingFlags.NonPublic | BindingFlags.Static);
                if (stylesType == null)
                {
                    Debug.LogError("Failed to get Styles type.");
                    return;
                }

                FieldInfo commandField = stylesType.GetField("command", BindingFlags.Public | BindingFlags.Static);
                if (commandField == null)
                {
                    Debug.LogError("Failed to get command field.");
                }
                else
                {
                    buttonStyle = (GUIStyle)commandField.GetValue(null);
                }
                
                buttonStyle.fixedHeight = 22;
                buttonStyle.fixedWidth = 42;
            }
        }
#endregion
    }
}
#endif //UNITY_EDITOR
